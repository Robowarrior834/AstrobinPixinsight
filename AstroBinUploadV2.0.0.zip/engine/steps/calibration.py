"""
Calibration Matching Module - AstroBin Upload Utility v2.0.0

This module implements the 'Calibration Matcher' logic, identifying which 
Dark, Flat, and Bias frames belong to each Light frame. 

Improvements:
- Strict Linear Gain Handshake.
- Strict Light-Frame Authority (Drop mismatched linear gains).
- Master Preference (If Master exists, ignore Raws).
"""

import pandas as pd
import numpy as np
import logging
from models import SessionState
from constants import InternalColumns, ImageType

class CalibrationMatcherStep:
    """
    Associates calibration frames with their corresponding LIGHT frames.
    """
    def execute(self, state: SessionState) -> SessionState:
        """
        Executes matching logic with strict 'Light-Frame Authority' pruning.
        """
        df = state.processed_df
        if df.empty: return state

        # --- Stage 1: Hybrid Handshake (EGAIN with GAIN Fallback) ---
        # We prioritize EGAIN if it exists (not 1.0), else fall back to linear GAIN.
        def create_hybrid_key(row):
            try:
                egain_val = float(row[InternalColumns.EGAIN])
                # Use a rounded signature (2 decimals) to bridge precision differences (0.2467 -> 0.25)
                if abs(egain_val - 1.0) > 0.0001:
                    return f"E_{egain_val:.2f}"
            except:
                pass
            
            # Fallback to Linear Gain anchor
            try:
                gain_val = int(round(float(row[InternalColumns.GAIN])))
                return f"G_{gain_val}"
            except:
                return "G_0"

        df[InternalColumns.GAIN_MATCH] = df.apply(create_hybrid_key, axis=1)
        
        # --- Stage 2: Light-Frame Authority (Strict Pruning) ---
        # Extract valid anchors from Light frames. 
        is_light = df[InternalColumns.IMAGE_TYPE] == ImageType.LIGHT.value
        lights_auth = df[is_light].copy()
        
        if not lights_auth.empty:
            # Anchor set for Darks/Bias (EGAIN + Binning)
            dark_bias_anchors = set(zip(
                lights_auth[InternalColumns.GAIN_MATCH],
                lights_auth[InternalColumns.BINNING]
            ))
            
            # Anchor set for Flats (Filter + EGAIN + Binning)
            # We strictly enforce that Flats must match the EGAIN of the Light.
            flat_anchors = set(zip(
                lights_auth[InternalColumns.FILTER_NAME].astype(str).str.lower(),
                lights_auth[InternalColumns.GAIN_MATCH],
                lights_auth[InternalColumns.BINNING]
            ))

            def is_orphaned(row):
                itype = str(row[InternalColumns.IMAGE_TYPE]).upper()
                if itype == ImageType.LIGHT.value: return False
                
                gain = row[InternalColumns.GAIN_MATCH]
                binning = row[InternalColumns.BINNING]
                filt = str(row[InternalColumns.FILTER_NAME]).lower()
                
                # Rule 1: Flats must match Filter AND Gain AND Binning
                if "FLAT" in itype and "DARK" not in itype:
                    return (filt, gain, binning) not in flat_anchors
                
                # Rule 2: Darks/Bias must match Gain AND Binning
                # (Ignore filter for these)
                if any(t in itype for t in ["DARK", "BIAS"]):
                    return (gain, binning) not in dark_bias_anchors
                
                return False

            # Completely discard orphaned calibration data
            # This drops the Gain 1 flats if Lights are Gain 100
            mask_orphaned = df.apply(is_orphaned, axis=1)
            df = df[~mask_orphaned].copy()

        # --- Stage 3: Segmentation ---
        lights_mask = df[InternalColumns.IMAGE_TYPE] == ImageType.LIGHT.value
        lights = df[lights_mask].copy()
        cals = df[~lights_mask].copy()
        
        if lights.empty: 
            state.processed_df = df
            return state

        # Initialize counts
        for col in ['darks', 'flats', 'flatDarks', 'bias']:
            lights[col] = 0

        # --- Stage 4: Matching Loop with Master Preference ---
        for idx, row in lights.iterrows():
            
            # 4a. Identify Candidates
            # Darks: Match Gain, Bin, Duration
            dark_candidates = cals[
                cals[InternalColumns.IMAGE_TYPE].str.upper().str.contains('DARK', na=False) & \
                ~cals[InternalColumns.IMAGE_TYPE].str.upper().str.contains('FLAT', na=False) & \
                (cals[InternalColumns.GAIN_MATCH] == row[InternalColumns.GAIN_MATCH]) & \
                (cals[InternalColumns.BINNING] == row[InternalColumns.BINNING]) & \
                (cals[InternalColumns.DURATION] == row[InternalColumns.DURATION])
            ]

            # Bias: Match Gain, Bin
            bias_candidates = cals[
                cals[InternalColumns.IMAGE_TYPE].str.upper().str.contains('BIAS', na=False) & \
                (cals[InternalColumns.GAIN_MATCH] == row[InternalColumns.GAIN_MATCH]) & \
                (cals[InternalColumns.BINNING] == row[InternalColumns.BINNING])
            ]

            # Flats: Match Filter, Gain, Bin
            flat_candidates = cals[
                cals[InternalColumns.IMAGE_TYPE].str.upper().str.contains('FLAT', na=False) & \
                ~cals[InternalColumns.IMAGE_TYPE].str.upper().str.contains('DARK', na=False) & \
                (cals[InternalColumns.FILTER_NAME].str.lower() == str(row[InternalColumns.FILTER_NAME]).lower()) & \
                (cals[InternalColumns.GAIN_MATCH] == row[InternalColumns.GAIN_MATCH]) & \
                (cals[InternalColumns.BINNING] == row[InternalColumns.BINNING])
            ]

            # 4b. Apply Master Preference Rule
            # If a Master exists in the candidates, use ONLY the Master(s).
            # Otherwise, use all Raw candidates.
            
            def resolve_count(candidates):
                if candidates.empty: return 0
                
                # Check for Master presence
                is_master_mask = candidates[InternalColumns.IMAGE_TYPE].str.upper().str.contains('MASTER', na=False)
                
                if is_master_mask.any():
                    # If Masters exist, keep ONLY the first one found to prevent double-counting 
                    # between multiple identified master versions of the same data.
                    final_set = candidates[is_master_mask].iloc[[0]]
                else:
                    # Use all raws
                    final_set = candidates
                
                return int(final_set[InternalColumns.NUMBER].sum())

            # 4c. Assign Counts
            lights.at[idx, 'darks'] = resolve_count(dark_candidates)
            lights.at[idx, 'bias']  = resolve_count(bias_candidates)
            lights.at[idx, 'flats'] = resolve_count(flat_candidates)
            
            # DarkFlats usually don't have Masters in the same way, but applying safe logic
            df_candidates = cals[
                cals[InternalColumns.IMAGE_TYPE].str.upper().str.contains('DARKFLAT', na=False) & \
                (cals[InternalColumns.FILTER_NAME].str.lower() == str(row[InternalColumns.FILTER_NAME]).lower()) & \
                (cals[InternalColumns.GAIN_MATCH] == row[InternalColumns.GAIN_MATCH])
            ]
            lights.at[idx, 'flatDarks'] = int(df_candidates[InternalColumns.NUMBER].sum())

        # --- Stage 5: Reintegration ---
        # Combine enriched lights with authority-validated calibration
        df = pd.concat([lights, cals], ignore_index=True)
        
        state.processed_df = df
        return state