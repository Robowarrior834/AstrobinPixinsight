"""
Standard Metadata Normalization Module - AstroBin Upload Utility v2.0.0

This module implements the first stage of the transformation pipeline: 
'NormalizeHeadersStep'. Its primary responsibility is to take the raw, 
often inconsistent metadata from FITS/XISF headers and transform it into 
 a standardized internal format.

Tasks performed:
1.  **Hardware Overrides**: Mapping custom hardware keywords (e.g., 'EXPTIME') 
    to internal standard keys (e.g., 'exposure').
2.  **Default Injection**: Filling missing metadata with user-defined defaults.
3.  **IMAGETYP Normalization**: Standardizing frame types (LIGHT, FLAT, etc.) 
    using substring matching.
4.  **Type Hardening**: Ensuring critical columns are numeric (float/int) and 
    applying fallbacks for 'NaN' values.
"""

import pandas as pd
import numpy as np
import logging
from models import SessionState
from constants import FITSKeywords, InternalColumns, ImageType, ConfigSections

class NormalizeHeadersStep:
    """
    Sanitizes raw FITS/XISF metadata into a standardized internal format.
    """
    def execute(self, state: SessionState) -> SessionState:
        """
        Executes the normalization logic on the raw_df.

        Args:
            state (SessionState): The current pipeline state.
            
        Returns:
            SessionState: The state with a populated and cleaned processed_df.
        """
        # Create a working copy of the raw data
        df = state.raw_df.copy()
        config = state.config
        logger = logging.getLogger("AstroBinV2")

        # --- Stage 1: Hardware Overrides ---
        # We process each override in the order specified in the configuration.
        # The first matching hardware key in the list takes precedence.
        for internal_key, hw_keys in config.overrides.items():
            combined_series = None
            found_cols = []
            for hw_key in hw_keys:
                # Case-insensitive search for matching hardware columns
                matching_cols = [c for c in df.columns if c.upper() == hw_key.upper()]
                if matching_cols:
                    source = matching_cols[0]
                    found_cols.append(source)
                    if combined_series is None:
                        combined_series = df[source].copy()
                    else:
                        # Coalesce: keep the highest priority value, fill gaps with lower priority
                        combined_series = combined_series.fillna(df[source])
            
            if combined_series is not None:
                df[internal_key] = combined_series
                # Remove original hardware columns to prevent redundancy, 
                # but keep the internal_key column if it was one of the sources.
                for col in found_cols:
                    if col != internal_key and col in df.columns:
                        df.drop(columns=[col], inplace=True)

        # --- Stage 2: Default Injection ---
        # For any core metadata still missing after extraction and overrides, 
        # inject the user-defined fallback values.
        for k, v in config.defaults.items():
            if k not in df.columns:
                df[k] = v

        # --- Stage 3: Column Standardization ---
        # Normalize all column names to lowercase for consistent internal processing.
        # We must also merge any duplicate columns created by case variations (e.g., 'GAIN' and 'gain').
        df.columns = [c.lower() for c in df.columns]
        
        # Identify and merge duplicate columns
        if df.columns.duplicated().any():
            # Group by column name and coalesce (take the first non-null value)
            df = df.groupby(level=0, axis=1).first()
        
        # --- Stage 4: Initial Filtering ---
        # Drop 'MASTERLIGHT' frames.
        # We calculate exposures from individual subs; masters would double the total.
        itype_col = InternalColumns.IMAGE_TYPE
        if itype_col in df.columns:
            df[itype_col] = df[itype_col].astype(str).str.upper()
            mask_drop = df[itype_col].str.contains('MASTERLIGHT', case=False, na=False) | \
                        df[itype_col].str.contains('MASTER LIGHT', case=False, na=False) | \
                        (df[itype_col] == 'NAN')
            df = df[~mask_drop].copy()

        # --- Stage 5: Master Preference Filtering ---
        # Execute preference before normalization to allow substring matching (FLAT vs MASTERFLAT)
        df = self._execute_master_preference(df)

        # --- Stage 6: IMAGETYP Normalization (Post-Preference) ---
        if itype_col in df.columns:
            type_map = {
                'LIGHT': ImageType.LIGHT.value,
                'FLAT': ImageType.FLAT.value,
                'DARK': ImageType.DARK.value,
                'BIAS': ImageType.BIAS.value,
                'MASTERFLAT': ImageType.MASTER_FLAT.value,
                'MASTER FLAT': ImageType.MASTER_FLAT.value,
                'MASTERDARK': ImageType.MASTER_DARK.value,
                'MASTER DARK': ImageType.MASTER_DARK.value,
                'MASTERBIAS': ImageType.MASTER_BIAS.value,
                'MASTER BIAS': ImageType.MASTER_BIAS.value,
                'MASTERDARKFLAT': ImageType.MASTER_DARKFLAT.value,
                'DARKFLAT': ImageType.DARK_FL_VALUE if hasattr(ImageType, 'DARK_FL_VALUE') else ImageType.DARK_FLAT.value,
                'DARK FLAT': ImageType.DARK_FLAT.value
            }
            
            # Apply mappings (longer keywords first to prevent partial matches like 'DARK' matching 'DARKFLAT')
            for keyword, normalized in sorted(type_map.items(), key=lambda x: len(x[0]), reverse=True):
                mask = df[itype_col].str.contains(keyword, case=False, na=False)
                df.loc[mask, itype_col] = normalized

        # --- Stage 7: Core Column Hardening ---
        # Ensure critical columns exist and are strictly typed.
        core_columns = {
            InternalColumns.GAIN: 0,
            InternalColumns.EGAIN: 1.0,
            InternalColumns.DURATION: 0.0,
            InternalColumns.SENSOR_COOLING: -10.0,
            InternalColumns.FOCAL_LENGTH: 500,
            InternalColumns.F_NUMBER: 5.0,
            InternalColumns.PIXEL_SIZE: 3.76,
            InternalColumns.SITE_LAT: 0.0,
            InternalColumns.SITE_LONG: 0.0,
            InternalColumns.BORTLE: 4.0,
            InternalColumns.MEAN_SQM: 21.0,
            InternalColumns.TEMPERATURE: 20.0,
            InternalColumns.TARGET: 'Unknown',
            InternalColumns.FILTER_NAME: 'No Filter',
            InternalColumns.SITE_NAME: 'Unknown Site',
            InternalColumns.BINNING: 1,
            InternalColumns.HFR: 1.0,
            InternalColumns.MEAN_FWHM: 0.0,
            InternalColumns.IMSCALE: 1.0,
            InternalColumns.NUMBER: 1,
            'darks': 0, 'flats': 0, 'flatDarks': 0, 'bias': 0
        }
        
        for col, default in core_columns.items():
            if col not in df.columns:
                # Initialize missing core columns with defaults
                df[col] = default
            else:
                # Type-cast existing columns to numeric and fill NaNs
                if col in [InternalColumns.EGAIN, 
                          InternalColumns.SENSOR_COOLING, InternalColumns.FOCAL_LENGTH, 
                          InternalColumns.F_NUMBER, InternalColumns.PIXEL_SIZE, 
                          InternalColumns.SITE_LAT, InternalColumns.SITE_LONG,
                          InternalColumns.BINNING, InternalColumns.BORTLE, 
                          InternalColumns.MEAN_SQM]:
                    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(default).astype(float)
                elif col == InternalColumns.DURATION:
                    # Round duration to 2 decimal places for consistent grouping/matching
                    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(default).round(2).astype(float)
                elif col == InternalColumns.NUMBER:
                    # Special handling for NUMBER: preserve existing counts from masters
                    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(1).astype(int)
                elif col == InternalColumns.GAIN:
                    # Gain is strictly a linear integer (e.g. 100, 1, 0)
                    # We prioritize existing numeric GAIN from headers.
                    df[col] = pd.to_numeric(df[col], errors='coerce').fillna(default).round().astype(int)
                elif col == InternalColumns.SITE_NAME:
                    # Standardize Site Names as strings
                    df[col] = df[col].astype(str).replace('nan', default)

        state.processed_df = df
        return state

    def _execute_master_preference(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Final authority on calibration hierarchy. 
        If a group of frames (same hardware axes) contains a MASTER, 
        discard everything else in that group.
        """
        itype_col = InternalColumns.IMAGE_TYPE
        
        # 1. Identify Calibration vs Light using original labels
        def is_cal(val):
            v = str(val).upper()
            return any(t in v for t in ['FLAT', 'DARK', 'BIAS']) and 'LIGHT' not in v

        cals_mask = df[itype_col].apply(is_cal)
        lights = df[~cals_mask].copy()
        cals = df[cals_mask].copy()
        
        if cals.empty: return df

        # 2. Grouping key must associate 'FLAT' with 'MASTER FLAT'
        def get_group_key(row):
            orig_itype = str(row[itype_col]).upper()
            # Normalize base type: 'MASTER FLAT' -> 'FLAT', 'DARK' -> 'DARK'
            # Stripping 'MASTER' and removing spaces ensures 'MASTER FLAT' groups with 'FLAT'
            base_type = orig_itype.replace('MASTER', '').replace(' ', '').strip()
            
            # Use raw numeric values for precise hardware grouping
            try:
                gain = int(round(float(row[InternalColumns.GAIN])))
            except:
                gain = 0
                
            try:
                # Reduce precision to 2 decimals to bridge master/raw EGAIN differences
                egain = f"{float(row[InternalColumns.EGAIN]):.2f}"
            except:
                egain = "1.00"
                
            binning = str(row[InternalColumns.BINNING]).strip()
            
            # Filter normalization for grouping
            import re
            filter_val = row.get('filter', row.get('FILTER', 'No Filter'))
            filter_name = str(filter_val).lower().strip()
            # Remove common prefixes like 'filter_' or 'filter-'
            filter_name = re.sub(r'^filter[_-]', '', filter_name).strip()
            
            if base_type in ['DARK', 'BIAS']:
                try:
                    duration = f"{float(row[InternalColumns.DURATION]):.2f}"
                except:
                    duration = "0.00"
                return (base_type, gain, egain, binning, duration)
            else:
                return (base_type, gain, egain, binning, filter_name)

        cals['_group_key'] = cals.apply(get_group_key, axis=1)
        
        # 3. Master Preemption: Within each group, if a Master exists, keep ONLY one master.
        final_cals = []
        for _, group in cals.groupby('_group_key'):
            is_master_mask = group[itype_col].astype(str).str.upper().str.contains('MASTER', na=False)
            if is_master_mask.any():
                # KEEP ONLY the first master frame found in this hardware group, drop all raws
                final_cals.append(group[is_master_mask].iloc[[0]])
            else:
                # Keep all raw frames if no master exists
                final_cals.append(group)
        
        if final_cals:
            cals = pd.concat(final_cals, ignore_index=True).drop(columns=['_group_key'])
        
        return pd.concat([lights, cals], ignore_index=True)
