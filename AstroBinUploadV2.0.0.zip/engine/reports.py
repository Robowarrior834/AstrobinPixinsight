"""
Reporting Module - AstroBin Upload Utility v2.0.0

This module is responsible for transforming aggregated session data into a 
highly detailed, human-readable text report. It mirrors the high-quality 
formatting standards established in legacy versions, providing a clear 
overview of equipment, environmental conditions, and exposure statistics.

The generator supports multi-site sessions and complex mosaics by 
intelligently grouping frames by site, target, and image type.
"""

import logging
import pandas as pd
from typing import Tuple, Union, List
from datetime import datetime
from constants import ImageType, InternalColumns

def seconds_to_hms(seconds: Union[int, float], logger: logging.Logger, aligned: bool = False) -> str:
    """
    Converts a raw duration in seconds into a formatted HH:MM:SS string.

    Args:
        seconds (float): Total seconds to convert.
        logger (logging.Logger): Application logger for error handling.
        aligned (bool): If True, uses fixed-width padding for tabular display.

    Returns:
        str: Formatted string (e.g., "1 hrs 30 mins 15.00 secs").
    """
    try:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = float(seconds % 60)
        
        # Aligned formatting is used within the ASCII tables for vertical consistency
        if aligned:
            return f"{hours:>6} hrs {minutes:>6} mins {secs:>6.2f} secs"
        return f"{hours} hrs {minutes} mins {secs:.2f} secs"
    except Exception:
        return "0 hrs 0 mins 0.00 secs"

def get_target_details(group: pd.DataFrame, logger: logging.Logger) -> str:
    """
    Identifies and formats the imaging target name from a group of frames.
    
    Includes specific logic for detecting mosaics based on 'Panel' keywords 
    in the target names.

    Args:
        group (pd.DataFrame): Dataframe containing a subset of Light frames.
        logger (logging.Logger): Application logger.

    Returns:
        str: Formatted target name string.
    """
    target_format = " Target: {}"
    if group.empty: return target_format.format("No target data")
    
    # Extract unique target names, dropping NaNs
    unique_targets = group[InternalColumns.TARGET].dropna().unique()
    
    # Mosaic Detection: If multiple targets contain 'Panel', summarize as a mosaic
    panels = [str(t) for t in unique_targets if 'Panel' in str(t)]
    if panels:
        # Extract the base name (e.g., 'M31' from 'M31 Panel 1')
        base_name = panels[0].split('Panel')[0].strip()
        return target_format.format(f"{base_name} {len(panels)} Panel Mosaic")
    
    # Default behavior: Return the first target found in the group
    return target_format.format(unique_targets[0] if len(unique_targets) > 0 else "Unknown")

def get_equipment_used(group: pd.DataFrame, df: pd.DataFrame, logger: logging.Logger) -> str:
    """
    Constructs a list of hardware and software used during the session.

    Args:
        group (pd.DataFrame): Subset of Light frames for hardware extraction.
        df (pd.DataFrame): Full session dataframe for software version extraction.
        logger (logging.Logger): Application logger.

    Returns:
        str: Multiline string containing the equipment list.
    """
    s = ["\nEquipment used:"]
    fmt = "\t{:<20}: {}"
    
    # Mapping of labels to internal column names
    items = {
        'Telescope': InternalColumns.TELESCOPE,
        'Camera': InternalColumns.CAMERA,
        'Filterwheel': InternalColumns.FILTER_WHEEL,
        'Focuser': InternalColumns.FOCUSER,
        'Rotator': InternalColumns.ROTATOR_NAME
    }
    
    # Extract hardware names from the first light frame (assumes static hardware per target)
    for label, col in items.items():
        if col in group.columns:
            val = group[col].iloc[0]
            if pd.notna(val) and str(val).lower() not in ['none', 'nan', '']:
                s.append(fmt.format(label, val))
            
    # Software version extraction: Collect all unique software strings found across all files
    sw_set = set(group[InternalColumns.SWCREATE].dropna().unique())
    sw_set.update(df[InternalColumns.SWCREATE].dropna().unique())
    
    if sw_set:
        # Sort so that the 'main' software usually appears first
        sw_list = sorted(list(sw_set), reverse=True) 
        s.append(fmt.format("Capture software", sw_list.pop(0)))
        # List additional software modules indented underneath
        for item in sw_list:
            s.append(fmt.format("", item))
            
    return "\n".join(s) + "\n"

def get_observation_period(group: pd.DataFrame, logger: logging.Logger) -> str:
    """
    Summarizes the dates, session counts, and temperature ranges.

    Args:
        group (pd.DataFrame): Subset of Light frames.
        logger (logging.Logger): Application logger.

    Returns:
        str: Formatted observation period summary.
    """
    s = ["\nObservation period:"]
    fmt = "\t{:<25}: {}"
    
    # Extract pre-calculated session statistics from the broadcasted columns
    start = group[InternalColumns.START_DATE].iloc[0] if InternalColumns.START_DATE in group.columns else "N/A"
    end = group[InternalColumns.END_DATE].iloc[0] if InternalColumns.END_DATE in group.columns else "N/A"
    days = group[InternalColumns.NUM_DAYS].iloc[0] if InternalColumns.NUM_DAYS in group.columns else 0
    sessions = group[InternalColumns.SESSIONS].iloc[0] if InternalColumns.SESSIONS in group.columns else 0
    
    s.append(fmt.format("Start date", start))
    s.append(fmt.format("End date", end))
    s.append(fmt.format("Days", int(days)))
    s.append(fmt.format("Observation sessions", int(sessions)))
    
    # Temperature Statistics
    if InternalColumns.TEMP_MIN in group.columns:
        s.append(fmt.format("Min temperature", f"{group[InternalColumns.TEMP_MIN].min():.1f}\u00B0C"))
        s.append(fmt.format("Max temperature", f"{group[InternalColumns.TEMP_MAX].max():.1f}\u00B0C"))
        s.append(fmt.format("Mean temperature", f"{group[InternalColumns.TEMPERATURE].mean():.1f}\u00B0C"))
    
    return "\n".join(s) + "\n"

def format_image_type_table(group: pd.DataFrame, imagetype: str, logger: logging.Logger, light_filters: set = None, light_gains: set = None) -> Tuple[str, float]:
    """
    Constructs an ASCII table summarizing frame counts and exposures for a specific type.
    
    For Light frames, data is grouped by target and filter. 
    For Calibration frames, data is consolidated by filter and gain.

    Args:
        group (pd.DataFrame): The full site-level dataframe.
        imagetype (str): The specific ImageType to format (e.g., 'LIGHT', 'FLAT').
        logger (logging.Logger): Application logger.
        light_filters (set, optional): Set of filter names used in Light frames.
        light_gains (set, optional): Set of linear Gain values used in Light frames.

    Returns:
        Tuple[str, float]: (The formatted ASCII table, Total exposure time in seconds).
    """
    lines = []
    total_exposure = 0.0
    
    # Filter for the specific image type requested
    image_group = group[group[InternalColumns.IMAGE_TYPE] == imagetype].copy()
    
    # Calibration Filtering: Only show Calibration for (Filter and/or Gain) that were actually used for Lights
    # This prevents clutter from calibration files that don't belong to the current session.
    if light_filters is not None and "FLAT" in imagetype.upper():
        image_group = image_group[image_group[InternalColumns.FILTER_NAME].astype(str).str.lower().isin(light_filters)]
    
    if light_gains is not None and imagetype != ImageType.LIGHT.value:
        # Strictly exclude calibration frames whose linear Gain doesn't match any Light frame Gain
        image_group = image_group[image_group[InternalColumns.GAIN_MATCH].isin(light_gains)]

    if image_group.empty: return "", 0.0

    # Common grouping keys for the summary table
    table_group_keys = [InternalColumns.FILTER_NAME, InternalColumns.GAIN_MATCH, InternalColumns.DURATION]

    if imagetype == ImageType.LIGHT.value:
        lines.append(f"\n {imagetype}S:")
        # Lights are grouped by Target first
        for target, t_group in image_group.groupby(InternalColumns.TARGET, observed=True):
            lines.append(f" Target: {target}\n")
            header = " {:<8} {:<8} {:<8} {:<12} {:<12} {:<12} {:<12} {:<15} {:<15}"
            lines.append(header.format("Filter", "Frames", "Gain", "Egain", "Mean FWHM", "Sensor Temp", "Mean Temp", "Exposure", "Total Exposure"))
            
            t_exposure_target = 0.0
            
            # Aggregate stats across multiple sessions/nights for this specific target
            summary_agg = t_group.groupby(table_group_keys, observed=True).agg({
                InternalColumns.NUMBER: 'sum',
                InternalColumns.GAIN: 'first',
                InternalColumns.EGAIN: 'mean',
                InternalColumns.MEAN_FWHM: 'mean',
                InternalColumns.SENSOR_COOLING: 'mean',
                InternalColumns.TEMPERATURE: 'mean'
            }).reset_index()

            for _, row in summary_agg.iterrows():
                row_total_exposure = row[InternalColumns.NUMBER] * row[InternalColumns.DURATION]
                t_exposure_target += row_total_exposure
                
                # Format gain for display (using linear integer GAIN)
                gain_val = row[InternalColumns.GAIN]
                gain_str = str(int(round(float(gain_val)))) if pd.notna(gain_val) else "N/A"
                egain_str = f"{float(row[InternalColumns.EGAIN]):.2f} e/ADU"
                
                lines.append(header.format(
                    str(row[InternalColumns.FILTER_NAME]), int(row[InternalColumns.NUMBER]), gain_str, egain_str,
                    f"{row[InternalColumns.MEAN_FWHM]:.2f} arcsec", f"{row[InternalColumns.SENSOR_COOLING]:.1f}\u00B0C", f"{row[InternalColumns.TEMPERATURE]:.1f}\u00B0C",
                    f"{row[InternalColumns.DURATION]:.2f} secs", seconds_to_hms(row_total_exposure, logger, aligned=True)
                ))
            lines.append(f"\n Exposure time for {target}: {seconds_to_hms(t_exposure_target, logger)}\n")
            total_exposure += t_exposure_target
    else:
        # Calibration Frames: Consolidate by filter/gain/exposure (no target grouping)
        # Normalize labels to MASTER[TYPE]S as per v1.4.7 standards
        label_map = {
            'DARK': 'MASTERDARKS',
            'FLAT': 'MASTERFLATS',
            'BIAS': 'MASTERBIAS',
            'DARKFLAT': 'MASTERDARKFLATS',
            'MASTERDARK': 'MASTERDARKS',
            'MASTERFLAT': 'MASTERFLATS',
            'MASTERBIAS': 'MASTERBIAS',
            'MASTERDARKFLAT': 'MASTERDARKFLATS'
        }
        display_label = label_map.get(imagetype.upper(), f"MASTER{imagetype.upper()}S")
        
        lines.append(f"\n {display_label}:\n")
        header = " {:<10} {:<8} {:<10} {:<15} {:<12} {:<15}"
        lines.append(header.format("Filter", "Frames", "Gain", "Egain", "Exposure", "Total Exposure"))
        
        summary_agg = image_group.groupby(table_group_keys, observed=True).agg({
            InternalColumns.NUMBER: 'sum',
            InternalColumns.GAIN: 'first',
            InternalColumns.EGAIN: 'mean'
        }).reset_index()

        for _, row in summary_agg.iterrows():
            row_total_exposure = row[InternalColumns.NUMBER] * row[InternalColumns.DURATION]
            total_exposure += row_total_exposure
            
            # Format gain for display (using linear integer GAIN)
            gain_val = row[InternalColumns.GAIN]
            gain_str = str(int(round(float(gain_val)))) if pd.notna(gain_val) else "N/A"
            egain_str = f"{float(row[InternalColumns.EGAIN]):.2f} e/ADU"
            
            # For Dark/Bias, the filter column should be blank if it is 'No Filter'
            filter_val = str(row[InternalColumns.FILTER_NAME])
            if filter_val == 'No Filter': filter_val = ""

            lines.append(header.format(
                filter_val, int(row[InternalColumns.NUMBER]), gain_str, egain_str,
                f"{row[InternalColumns.DURATION]:.2f} secs", seconds_to_hms(row_total_exposure, logger, aligned=True)
            ))
            
    return "\n".join(lines), total_exposure

def generate_full_summary(df: pd.DataFrame, logger: logging.Logger, total_scanned: int) -> str:
    """
    Orchestrates the generation of the full multi-site session report.
    
    This is the primary entry point for the reporting engine. It iterates through 
    sites, generates equipment and observation summaries, and builds detail 
    tables for every image type found.

    Args:
        df (pd.DataFrame): The fully aggregated session dataframe.
        logger (logging.Logger): Application logger.
        total_scanned (int): Total count of raw files identified on disk.

    Returns:
        str: The complete, formatted text report.
    """
    if df.empty: return "No data available for reporting."
    
    report = []
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    report.append(f"Observation session summary\nGenerated {now}")
    
    # Iterate through each Site found in the session
    for site, site_group in df.groupby(InternalColumns.SITE_NAME, observed=True):
        lights = site_group[site_group[InternalColumns.IMAGE_TYPE] == ImageType.LIGHT.value]
        if lights.empty: continue # Skip sites that only have calibration frames
        
        # Determine unique filters and gains for the light frames to filter irrelevant calibration data
        light_filters = set(lights[InternalColumns.FILTER_NAME].astype(str).str.lower().unique())
        light_gains = set(lights[InternalColumns.GAIN_MATCH].unique())
        
        # 1. Target and Site Metadata
        report.append(get_target_details(lights, logger))
        report.append(f"\nSite: {site}")
        report.append(f"\tLatitude: {site_group[InternalColumns.SITE_LAT].iloc[0]:.4f}\u00B0")
        report.append(f"\tLongitude: {site_group[InternalColumns.SITE_LONG].iloc[0]:.4f}\u00B0")
        report.append(f"\tBortle scale: {site_group[InternalColumns.BORTLE].iloc[0]:.1f}")
        report.append(f"\tSQM: {site_group[InternalColumns.MEAN_SQM].iloc[0]:.2f} mag/arcsec²")
        
        # 2. Hardware and Temporal Summaries
        report.append(get_equipment_used(lights, df, logger))
        report.append(get_observation_period(lights, logger))
        
        # 3. Formatted Data Tables (Ordered by importance)
        # We group raw and master types together for the report layout
        order = [
            (ImageType.LIGHT.value,), 
            (ImageType.FLAT.value, ImageType.MASTER_FLAT.value), 
            (ImageType.BIAS.value, ImageType.MASTER_BIAS.value),
            (ImageType.DARK.value, ImageType.MASTER_DARK.value),
            (ImageType.DARK_FLAT.value, ImageType.MASTER_DARKFLAT.value)
        ]
        
        unique_itypes = site_group[InternalColumns.IMAGE_TYPE].unique()
        processed_types = set()

        for type_tuple in order:
            # Find all types in the current group that belong to this category (e.g., DARK + MASTERDARK)
            matches = [u for u in unique_itypes if u in type_tuple]
            if matches:
                # Filter the site_group to include only these specific types for the table
                category_group = site_group[site_group[InternalColumns.IMAGE_TYPE].isin(matches)]
                
                # We use the primary type in the tuple for the formatting logic (determines the MASTER label)
                primary_type = type_tuple[0]
                
                table, exp = format_image_type_table(category_group, primary_type, logger, 
                                                   light_filters=light_filters, light_gains=light_gains)
                if table:
                    report.append(table)
                    report.append(f"\nTotal {primary_type} Exposure Time: {seconds_to_hms(exp, logger)}\n")
                
                processed_types.update(matches)
                    
    # Append global processing statistics
    report.append(f"\n Total number of images processed: {total_scanned}\n")
    return "\n".join(report)